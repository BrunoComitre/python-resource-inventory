import random
import time
import sys
import pandas as pd
from memory_profiler import profile
from profilehooks import timecall
from typing import List, NoReturn

class Timer():
    def __init__(self):
        self.start = time.time()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        end = time.time()
        runtime = end - self.start
        msg = 'A função levou {time} segundos para ser concluída'
        print(msg.format(time=runtime))
        print('='*100)
        print()

@timecall
@profile
def file_json(file: str) -> NoReturn:
    def read_file(file: str) -> List:
        return pd.read_json(file)

    content = read_file(file)
    lista = [x for x in range(len(content))]

    print(f'TAMANHO :: {sys.getsizeof(lista)}, TIPO :: {type(lista)}')


if __name__ == '__main__':
    with Timer():
        print(f'DEZ ITENS ::')
        print(file_json('dez_itens.json'))

    with Timer():
        print(f'CEM ITENS ::')
        print(file_json('cem_itens.json'))

    with Timer():
        print(f'MIL ITENS ::')
        print(file_json('um_mil.json'))

    with Timer():
        print(f'CINCO MIL ITENS ::')
        print(file_json('cinco_mil.json'))

    with Timer():
        print(f'QUINZE MIL ITENS ::')
        print(file_json('quinze_mil.json'))

    with Timer():
        print(f'QUARENTA E CINCO MIL ITENS ::')
        print(file_json('quarenta_cinco_mil.json'))
